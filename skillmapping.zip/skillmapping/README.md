# Skill Mapping Analysis

This Streamlit application allows users to upload an Excel file, select a domain, and visualize the number of unique experts and intermediates by subdomain. It also provides details for specific subdomains and expertise levels.

## Project Structure

